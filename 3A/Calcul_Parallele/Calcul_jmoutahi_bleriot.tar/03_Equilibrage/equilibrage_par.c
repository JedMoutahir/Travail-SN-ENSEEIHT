// Initialisation de MPI et de tout l'environnement necessaire

// Seulemnent le code parallele est presenté ici

if(my_rank == 0){
    // N nombre de pixels de l'image
    int N = get_image_size(filename);

    // allocation de la mémoire pour contenir l'image 
    // variable pixels : tableau de 3*N octets (3 octets par pixels, RVB)
    char *pixels = allocate_image(N);

    // lecture de l'image
    read_image(pixels, N, filename);
}

// On considère que la taille de l'image est un multiple du nombre de processus
char *local_pixels = allocate_image(N / size);

// Chaque processus MPI reçoit sa partie de l'image ; Complexité : p messages de taille 3 * N / p octets
MPI_Scatter(pixels, N / size, MPI_CHAR, local_pixels, N / size, MPI_CHAR, 0, MPI_COMM_WORLD);

// tableau lumi contenant la luminance de chaque pixel
// (valeur entre 0 et 255 => tableau d'entiers de taille N)
int *local_lumi = allocate_lumi(N / size);

// calcul de la luminance -> complexité : 1 calcul par pixel ; Complexité : N / p calculs
compute_luminance(local_lumi, local_pixels, N / size);

// tableau histo de taille 256 qui compte le nombre de pixels 
// ayant la luminance correspondante
int *local_histo = allocate_histo(256);

// calcul de l'histogramme -> complexité : 1 calcul par pixel ; Complexité : N / p calculs
compute_histo(local_histo, local_lumi, N);

// On combine les histogrammes locaux en un histogramme global dans chaque processus ; Complexité : Calculs : 256 ; Communication : 256 * p octetss
int *histo = allocate_histo(256);
MPI_Allreduce(local_histo, histo, 256, MPI_INT, MPI_SUM, MPI_COMM_WORLD);

// Équilibrage de l'image d'origine locale en utilisant l'histogramme global : 
// on crée une nouvelle image -> complexité : 1 calcul par pixel ; Complexité : N / p calculs
// la saturation (nombre de pixels ayant la valeur 0 ou la valeur 255)
// est aussi calculée
char *local_new_pixels = allocate_image(N / size);
int local_saturation;

equalize(local_new_pixels, &local_saturation, local_pixels, histo, N);

// On rassemble les images locales en une image globale dans le processus 0 ; Complexité : p messages de taille 3 * N / p octets
char *new_pixels = allocate_image(N);
MPI_Gather(local_new_pixels, N / size, MPI_CHAR, new_pixels, N / size, MPI_CHAR, 0, MPI_COMM_WORLD);

// On rassemble les saturations locales en une saturation globale dans le processus 0 ; Complexité : p messages de taille 1 octet
int saturation;
MPI_Reduce(&local_saturation, &saturation, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);

// sauvegarde de l'image égalisée
if(my_rank == 0){
    save_image(new_pixels, N, filename2);
}

// affichage de la saturation
printf("la saturation est de %d\n", saturation)